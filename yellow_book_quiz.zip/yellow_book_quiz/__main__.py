
# internal
import random

# my lib
from character_search.CharacterSearcher import *

# external
#import pyglet

# creater searcher
cs = CharacterSearcher()

# test search
#print(cs.search_character('的'))

#
# Settings
#

YELLOW_BOOK_DATA_DIR = "yellow_book/data/"
CHARACTER_WORKBOOK_FILE = YELLOW_BOOK_DATA_DIR + "character_workbook_dictionary.csv"

#
# Read from CSV File
#

yellow_book_df = pd.read_csv(CHARACTER_WORKBOOK_FILE)
yellow_book_df = yellow_book_df.set_index('chapter')
#
# quiz
#

#print(yellow_book_df.loc[1])

#from PIL import Image, ImageSequence
import os
def play_gif(file):

	cmd = "python3 -m gif_for_cli %s" % file
	os.system(cmd)


def quiz_on_char(char):

	# search
	info = cs.search_character(char)

	definitions = info['definitions']
	pinyin = info['pinyin']
	char = char

	# display definition
	print("\n\nDefinitions:, ", definitions)

	cmd = input("Skip [y]? anyother key for pinyin:\n[>]:")

	if cmd == 'y':
		print(pinyin)
		print(char)
		return

	# display pinyin
	print("Pinyin:, ", pinyin)
	cmd = input("Skip [y]? anyother key for gif (if avaible):\n[>]:")

	if cmd == 'y':
		print(definitions)
		print(pinyin)
		print(char)
		return

	# check gif if avaivble
	if info['stroke_order_gif_file'] is not None:
		play_gif(info['stroke_order_gif_file'])

	else:
		print(char)
		print("NO GIF FILE")


	return



chapters = [30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60]
N = 10

for q in range(N):

	print("\nQuestion %s/%s.\n" % (q, N))

	# select random character from given chapters
	rand_chapter = random.choice(chapters)
	chapter_chars = yellow_book_df.loc[rand_chapter].tolist()
	random_char = random.choice(chapter_chars)


	cmd = input("\nContinue...\n")
	quiz_on_char(random_char)




